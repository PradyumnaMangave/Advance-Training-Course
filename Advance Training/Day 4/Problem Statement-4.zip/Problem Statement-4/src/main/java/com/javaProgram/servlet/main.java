package com.javaProgram.servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javaProgram.dao.productDao;
import com.javaProgram.entity.product;

/**
 * Servlet implementation class JDBC_Connector
 */
@WebServlet("/main")
public class main extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public main() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    Connection con;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
		 response.setContentType("text/html");  
	        PrintWriter out=response.getWriter();  

	            	out.println("<h1>Books List</h1>");  
	  	          
	    	        List<product> list=productDao.getAllProduct();  
	    	          
	    	        out.print("<table border='1' width='100%'");  
	    	        out.print("<tr><th>Book Id</th><th>Book Name</th><th>Author</th><th>Price</th></tr>");  
	    	        for(product p:list){  
	    	         out.print("<tr><td>"+p.getBook_id()+"</td><td>"+p.getBook_Name()+"</td><td>"+p.getAuthor()+"</td><td>"+p.getPrice()+"</td></tr>");  
	    	        }  
	    	        out.print("</table>");         
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
