package com.javaProgram.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javaProgram.dbutil.JDBCConnector;



/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	String dt;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Connection con= JDBCConnector.initializeDatabase();
			String fname=request.getParameter("fname");
			String address=request.getParameter("address");
			String username=request.getParameter("username");
			String email=request.getParameter("email");
			String password=request.getParameter("password");
			String registration_date=request.getParameter("Registration_date");
			
			
			PreparedStatement ps=con.prepareStatement("insert into  user_details  values(?,?,?,?,?,?)");
			ps.setString(1, fname);
			ps.setString(2, address);
			ps.setString(3, email);
			ps.setString(4, username);
			ps.setString(5, password);
			ps.setString(6, registration_date);
			
			
			
			int i=ps.executeUpdate();
			
			if(i>0) {
				response.sendRedirect("page.jsp");
			}
			else {
				PrintWriter out=response.getWriter();
				out.println("unable to register..");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
