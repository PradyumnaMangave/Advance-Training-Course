package com.javaprogram;
import java.util.Scanner;

public class EvenNumber {

	public static void main(String[] args) {
		
		int n;
		
        System.out.println("Enter a number: ");
        Scanner scan= new Scanner(System.in);
        n=scan.nextInt();

		System.out.println("Even Numbers from 1 to "+n+" are: ");

		for (int i = 1; i <= n; i++) {

	

		   if (i % 2 == 0) {

		 System.out.println(i + " ");

		   }

		}

	}

}