package com.javaProgram.project;

public abstract class Instrument
{
public abstract void Play();
}