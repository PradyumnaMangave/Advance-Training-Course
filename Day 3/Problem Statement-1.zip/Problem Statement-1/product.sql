create database ProductManagement;
use ProductManagement;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `productdetails` (
  `ProductId` varchar(4) NOT NULL,
  `ProductName` varchar(20) NOT NULL,
  `ProductPrice` int(10) NOT NULL
) ;

--
-- Dumping data for table `productdetails`
--

INSERT INTO `productdetails` (`ProductId`, `ProductName`, `ProductPrice`) VALUES
('2355', 'Hair drayer', 1000),
('2314', 'hair Straightner', 1200),
('2315', 'LCD TV', 30000),
('2316', 'Refrigrator', 25000),
('2317', 'Air Conditioner', 27000),
('2318', 'sofaSet', 29000);
COMMIT;

 