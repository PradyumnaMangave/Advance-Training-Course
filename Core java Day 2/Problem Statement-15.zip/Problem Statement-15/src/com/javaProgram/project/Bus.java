
package com.javaProgram.project;

import java.io.*;

public class Bus {
	// Returns minimum number of platforms required
	public static int findPlatform(int arrival[], int depar[],
								int n)
	{

		// plat_needed indicates number of platforms
		// needed at a time
		int plat_needed = 1, result = 1;
		int i = 1, j = 0;

		// run a nested loop to find overlap
		for (i = 0; i < n; i++) {
			// minimum platform
			plat_needed = 1;

			for (j = i + 1; j < n; j++) {
				// check for overlap
				if ((arrival[i] >= arrival[j] && arrival[i] <= depar[j])
					|| (arrival[j] >= arrival[i]
						&& arrival[j] <= depar[i]))
					plat_needed++;
			}

			// update result
			result = Math.max(result, plat_needed);
		}

		return result;
	}

	// Driver Code
	public static void main(String[] args)
	{
		int arrival[] = { 900, 940, 950, 1100, 1500, 1800 };
		int depar[] = { 910, 1200, 1120, 1130, 1900, 2000 };
		int n = 6;
		System.out.println(
			"Minimum Number of Platforms Required = "
			+ findPlatform(arrival, depar, n));
	}
}
