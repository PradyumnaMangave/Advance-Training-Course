package com.javaProgram.project;
import java.util.Scanner;

public class Main {
	 private static boolean Shuffle_Check(String string1, String string2, String resultss) {
	        
	        String string3 = string1 + string2;
	        StringBuffer s = new StringBuffer(string3);

	        boolean flag = false;

	        char[] ch = resultss.toCharArray();

	        if (s.length() != resultss.length()) {
	            flag = false;
	        } else {

	            for (int i = 0; i < ch.length; i++) {
	                
	                String temp = Character.toString(ch[i]);

	                if (string3.contains(temp)) {

	                    s = s.deleteCharAt(s.indexOf(temp));
	                    string3 = new String(s);
	                    flag = true;
	                    
	                } else {
	                    flag = false;
	                    break;
	                }

	            }

	        }

	        if (flag) {
	            System.out.println("True");
	        } else {
	            System.out.println("False");
	        }
			return flag;

	    }

	  public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter string1 input");
        String string1 = sc.nextLine();
        
        System.out.println("Enter string2 input");
        String string2= sc.nextLine();
       
        System.out.println("Enter results you want answer");
        String resultss=sc.nextLine();
       
	      if (Shuffle_Check(string1, string2, resultss) == true) {
	        System.out.println(resultss + " is a valid shuffle of " + string1 + " and " + string2);
	      }
	      else {
	        System.out.println(resultss + " is not a valid shuffle of " + string1 + " and " + string2);
	      }
	   // }
	  }
}
