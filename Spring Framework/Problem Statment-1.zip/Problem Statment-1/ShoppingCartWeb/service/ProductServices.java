package com.springboot.service;

import java.util.List;

import com.springboot.entity.Product;

public interface ProductServices {
	
	

    public static void saveProduct(Product theProduct) {
		// TODO Auto-generated method stub
		
	}

    public static Product getProduct(int theId) {
		// TODO Auto-generated method stub
		return null;
	}

    public static void deleteProduct(int theId) {
		// TODO Auto-generated method stub
		
	}

	public List<Product> getProduct();

}
